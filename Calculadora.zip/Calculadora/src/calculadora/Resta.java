/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculadora;

/**
 *
 * @author Juan
 */
public class Resta extends Operacion { ////Hereda de Operacion y sobrescribe el método calcular() para sumar dos números.
    @Override //indica que estamos redefiniendo el método de la clase padre.
    public double calcular(double numero1, double numero2) {
        return numero1 - numero2;
    }
}
