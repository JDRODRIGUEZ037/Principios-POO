/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculadora;
import java.util.Scanner;

/**
 *
 * @author Juan
 */

import java.util.Scanner;

public class Calculadora {
    // Atributo Scanner para leer la entrada del usuario
    private Scanner scanner;

    // Constructor: Inicializa el Scanner
    public Calculadora() {
        scanner = new Scanner(System.in);
    }

    // Método para mostrar el menú de opciones
    public void mostrarMenu() {
        System.out.println("==== CALCULADORA ====");
        System.out.println("1. Sumar");
        System.out.println("2. Restar");
        System.out.println("3. Multiplicar");
        System.out.println("4. Dividir");
        System.out.println("5. Salir");
        System.out.print("Elige una opción: ");
    }

    // Método principal que ejecuta la lógica de la calculadora
    public void ejecutar() {
        int opcion;
        // Bucle do-while para mantener el menú activo hasta que el usuario elija salir
        do {
            mostrarMenu(); // Llama al método para mostrar el menú
            opcion = scanner.nextInt(); // Lee la opción del usuario
            
            // Si elige 3, muestra mensaje de despedida y termina el bucle
            if (opcion == 5) {
                System.out.println("¡Adiós!");
                break;
            }

            // Valida si la opción no es 1, 2, 3 o 4
            if (opcion < 1 || opcion > 4) {
                System.out.println("Opción inválida. Intenta de nuevo.");
                continue; // Vuelve al inicio del bucle
            }

            // Solicita los dos números al usuario
            System.out.print("Ingresa el primer número: ");
            double num1 = scanner.nextDouble();
            System.out.print("Ingresa el segundo número: ");
            double num2 = scanner.nextDouble();

            // Crea la operación según la elección 
            Operacion operacion; // La variable operacion es de tipo Operacion, pero apunta a un objeto Suma o Resta según la elección del usuario.
            operacion = switch (opcion) {
                case 1 -> new Suma();
                case 2 -> new Resta();
                case 3 -> new Multiplicacion();
                default -> new Division();
            }; // Instancia de Suma (herencia de Operacion)
            // Instancia de Resta (herencia de Operacion)
            // Instancia de Resta (herencia de Operacion)
            // Instancia de Resta (herencia de Operacion)

            // Ejecuta la operación y muestra el resultado
            double resultado = operacion.calcular(num1, num2);
            System.out.println("Resultado: " + resultado + "\n");

        } while (opcion != 3); // Condición para repetir el bucle
        
        scanner.close(); // Cierra el Scanner para liberar recursos
    }
}