/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package calculadora;

/**
 *
 * @author Juan
 */
public class Division extends Operacion {
    @Override
    public double calcular(double numero1, double numero2) {
        return numero1 / numero2;
    }
}
