/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package calculadora;

/**
 *
 * @author Juan
 */
public abstract class Operacion { // Clase Padre
    //Se fuerza a que las subclases implementen el método ya que tienen un logica comun
     public abstract double calcular(double numero1, double numero2); // Metodo que se heredara
     
}
    
